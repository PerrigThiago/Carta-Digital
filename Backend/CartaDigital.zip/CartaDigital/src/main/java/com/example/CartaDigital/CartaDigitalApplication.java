package com.example.CartaDigital;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CartaDigitalApplication {

	public static void main(String[] args) {
		SpringApplication.run(CartaDigitalApplication.class, args);
	}

}
